var ccoteLocObj ={
	Cancel_MANDATORY:"N", 
	Ok_ENABLED:"enabled", 
	delFlg_MANDATORY:"N", 
	funcCode_ENABLED:"enabled", 
	Clear_MANDATORY:"N", 
	funCode_MANDATORY:"N", 
	Clear_ENABLED:"enabled", 
	Submit_ENABLED:"enabled", 
	Go_ENABLED:"enabled", 
	Ok_MANDATORY:"N", 
	funcCode_MANDATORY:"N", 
	delFlg_ENABLED:"enabled", 
	schmDesc_MANDATORY:"N", 
	Submit_MANDATORY:"N", 
	Go_MANDATORY:"N", 
	schmCode_MANDATORY:"N", 
	Cancel_ENABLED:"enabled", 
	schmCode_ENABLED:"enabled", 
	schmDesc_ENABLED:"enabled", 
	funCode_ENABLED:"enabled"
	};
var ccoteProps =  new Properties(ccoteLocObj);
